from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CallbackQueryHandler
from ...models import Wallet, Coin
from ...helpers import radixapi
from ...helpers import ociswap
from .base import InlineRoute
from .start import StartRoute
import re, asyncio

class DetailWalletRoute(InlineRoute):
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.edit_text(self.text(), reply_markup = await self.keyboard(update.effective_user.id))

    def text(self):
        return "Select wallet"
    
    def notfound_text(self):
        return "No wallet found"

    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    async def keyboard(self, user_id: int):
        return InlineKeyboardMarkup([])
    
    @staticmethod
    def split_text(text, chunk_size=4096):
        chunks = []
        current_chunk = ""
        for line in text.splitlines():
            if len(current_chunk) + len(line) + 1 <= chunk_size:
                current_chunk += line + "\n"
            else:
                chunks.append(current_chunk)
                current_chunk = line + "\n"
        if current_chunk:
            chunks.append(current_chunk)
        return chunks

    # async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
    #     await super().enter(update, context)

    #     text = self.text()
    #     if not await Wallet.objects.filter(telegram_id = update.effective_user.id).aexists():
    #         text = self.notfound_text()

    #     await update.message.reply_text(text, reply_markup = await self.keyboard(update.effective_message.from_user.id))

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE, wallet_id = None, convert_to_price = 'XRD'):
        await super().enter(update, context)

        message_sent = await update.effective_message.reply_text('Wait...')
        if wallet_id is None:
            wallet_id = update.effective_message.text.removeprefix(f'/detail_wallet_')

        wallet = await Wallet.objects.filter(telegram_id = update.effective_user.id).aget(pk = wallet_id)
        tokens = await radixapi.get_balance(wallet.address)
        xrd_token = (await ociswap.get_ociswap_token('resource_rdx1tknxxxxxxxxxradxrdxxxxxxxxx009923554798xxxxxxxxxradxrd'))[0]

        if not tokens:
            await update.effective_message.edit_text(f'No coin found in wallet {wallet.name}', reply_markup = self.wallet_keyboard(wallet_id))
            return

        text = ['Token:']
        total_usd = [0]

        async def execute(token, text, total_usd):
            # coin = await Coin.objects.filter(telegram_id = update.effective_user.id).aget(coin_id = token['fungible_resource_address'])
            resource_address = token['fungible_resource_address']
            # coin = await ociswap.get_token(resource_address)
            # print(coin)
            amount = round(float(token['amount']), 4)

            token = (await radixapi.get_safe_token(resource_address))

            if not token.get('symbol'):
                return

            if not token.get('price'):
                price = "-"
            else:
                price = str(
                        round(
                            float(token['price']) * amount, 2
                        )
                ) + ' USD'

            total_usd[0] += token['price'] * amount
            text[0] += f'\n<b><a href="https://www.radixscan.io/entity/{resource_address}">${token["symbol"].upper()}</a></b> <code>{amount}</code> = {price}'
        
        await asyncio.gather(*[execute(token, text, total_usd) for token in tokens])

        staking_balance = round(await radixapi.get_staking_balance(wallet.address), 2)
        staking_balance_usd = round(
            staking_balance * float(xrd_token['price']['usd']['now'])
        )
        total_usd[0] += staking_balance_usd
        text[0] += f'\n\nStaking:\n<b><a href="https://www.radixscan.io/entity/resource_rdx1tknxxxxxxxxxradxrdxxxxxxxxx009923554798xxxxxxxxxradxrd">$XRD</a></b> {staking_balance} = {staking_balance_usd} USD'
        text[0] += f'\n\nTotal Balance:\n{round(total_usd[0], 4)} USD'
        texts = self.split_text(text[0], 3500)
        for text in texts:
            await update.message.reply_text(text, parse_mode = 'HTML')


    def route(self):
        return [
            MessageHandler(filters.Regex(r'^/detail_wallet_\d+$'), self.enter),
        ]