from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CallbackQueryHandler
from .base import BaseRoute
from .start import StartRoute
from asgiref.sync import sync_to_async
from ...helpers.ociswap import get_ociswap_token
from ...models import Pool
import re, asyncio

class PoolRoute(BaseRoute):
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.enter(update, context)

    async def text(self, update: Update):
        text = ['Your pool:\n']
        coins = Pool.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(coins)
        
        # for coin in coins: 
        async def execute(coin, text):
            token = await get_ociswap_token(coin.coin_id, list_ = False)
            price_now = round(float(token['liquidity']['xrd']['now']), 4)
            text[0] += f"\n<b><a href='https://www.radixscan.io/entity/{coin.coin_id}'>${token['symbol'].upper()}</a></b> : <code>{price_now}</code> XRD"

        await asyncio.gather(*[execute(coin, text) for coin in coins])

        return text[0]

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        message = await update.message.reply_text('Wait...')
        text = await self.text(update)
        await message.edit_text(text, parse_mode = 'HTML')

    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(StartRoute)) & filters.Text(StartRoute.POOL_TEXT), self.enter),
        ]

