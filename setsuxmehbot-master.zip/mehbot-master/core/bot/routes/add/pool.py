from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, \
    InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler, CallbackQueryHandler
from core.helpers.ociswap import find_ociswap_token
from ..base import CanBackRoute
from ....models import Pool
from . import AddRoute
from asgiref.sync import sync_to_async
from ....helpers.decorators import safe_end
import re, requests

class AddPoolRoute(CanBackRoute):
    CANCEL_TEXT = "❌ Cancel"
    ON_INPUT_COIN, ON_CONFIRM_COIN = range(2)
    TEXT = "Enter coin symbol or name (e.g OCI, ARC) or enter Resources ID :"

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.CANCEL_TEXT)]
            ],
            resize_keyboard = True
        )
    
    @safe_end
    async def input_coin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        coin: str = re.sub(r'\W', '', update.message.text)

        tokens = await find_ociswap_token(coin)

        if not tokens:
             await update.message.reply_text("Coin not found")
             return
        
        token = tokens[0]

        context.user_data['token'] = token
        
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Yes", callback_data = "yes"),
            InlineKeyboardButton("❌ No", callback_data = "no")],
        ])

        try:
            image = await sync_to_async(requests.get)(token["icon_url"])
            await update.message.reply_photo(InputFile(image.content), caption = f"<b>{token['name']}</b> is that correct?", reply_markup = reply_markup, parse_mode = "HTML")
        except:
            await update.message.reply_text(f"<b>{token['name']}</b> is that correct?", reply_markup = reply_markup, parse_mode = "HTML")

        return self.ON_CONFIRM_COIN

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text(self.TEXT, reply_markup = self.keyboard())
        return self.ON_INPUT_COIN

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await self.enter(update, context)

    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await AddRoute().rebuild(update, context)
        return ConversationHandler.END

    async def cancel_add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.delete_message()
        await self.rebuild(update, context)
        return self.ON_INPUT_COIN

    async def confirm_add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.delete_message()
        token = context.user_data['token']
        del context.user_data['token']
        if await Pool.objects.filter(telegram_id = update.effective_user.id).filter(coin_id = token["address"]).aexists():
            await update.effective_message.reply_text("pool has been registered")
            return
        
        await Pool.objects.acreate(
            name = token["name"],
            coin_id = token["address"],
            telegram_id = update.effective_user.id
        )
        await update.effective_message.reply_text("✅ Successfully")
        await AddRoute().rebuild(update, context)
        return ConversationHandler.END

    def route(self):
        filter_ = self.IsActiveFilter(hash(AddRoute)) & filters.Text(AddRoute.ADD_POOL_TEXT)
        return [ConversationHandler(
            entry_points = [MessageHandler(filter_, self.enter)],
            states = {
                self.ON_INPUT_COIN: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.input_coin)
                ],
                self.ON_CONFIRM_COIN: [
                    CallbackQueryHandler(self.cancel_add, '^no$'),
                    CallbackQueryHandler(self.confirm_add, '^yes$'),
                ]
            },
            fallbacks = [MessageHandler(filters.Text(self.CANCEL_TEXT), self.back)],
            per_user = True
        )]
