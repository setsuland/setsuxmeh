from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, \
    InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler, CallbackQueryHandler
from core.helpers.radishsquare import find_nfts, get_nft_detail_long_cache, get_nft_detail, get_nfts
# from core.helpers.radixapi import get_nft
from ..base import CanBackRoute
from ....models import NFT
from . import AddRoute
from ....helpers.decorators import safe_end
import re

class AddNFTRoute(CanBackRoute):
    CANCEL_TEXT = "❌ Cancel"
    ON_INPUT_COIN, ON_CONFIRM_COIN = range(2)
    TEXT = "Enter NFT name (e.g Arcane Labyrinth NFT) or Resources ID"

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.CANCEL_TEXT)]
            ],
            resize_keyboard = True
        )
    
    @safe_end
    async def input_coin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        coin: str = re.sub(r'\W', '', update.message.text)

        if coin.startswith('resource_'):
            nfts = await get_nfts()
            for nft in nfts:
                nft_detail = await get_nft_detail_long_cache(nft['id'])
                if nft_detail['address'] == coin:
                    tokens = await find_nfts(nft['name'])
                    break
        else:                    
            tokens = await find_nfts(coin)            

        if not tokens:
             await update.message.reply_text("NFT not found")
             return
        
        token = tokens[0]

        context.user_data['token'] = token
        
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Yes", callback_data = "yes"),
            InlineKeyboardButton("❌ No", callback_data = "no")],
        ])


        await update.message.reply_text(f"<b>{token['name']}</b> is that correct?", reply_markup = reply_markup, parse_mode = "HTML")

        return self.ON_CONFIRM_COIN

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text(self.TEXT, reply_markup = self.keyboard())
        return self.ON_INPUT_COIN

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await self.enter(update, context)

    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await AddRoute().rebuild(update, context)
        return ConversationHandler.END

    async def cancel_add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.delete_message()
        await self.rebuild(update, context)
        return self.ON_INPUT_COIN

    async def confirm_add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.callback_query.delete_message()
        token = context.user_data['token']
        address = (await get_nft_detail(token['id']))['address']
        del context.user_data['token']
        if await NFT.objects.filter(telegram_id = update.effective_user.id).filter(nft_id = address).aexists():
            await update.effective_message.reply_text("nft has been registered")
            return
        

        await NFT.objects.acreate(
            name = token["name"],
            nft_id = address,
            telegram_id = update.effective_user.id,
            radishsquare_id = token['id']
        )
        await update.effective_message.reply_text("✅ Successfully")
        await AddRoute().rebuild(update, context)
        return ConversationHandler.END

    def route(self):
        filter_ = self.IsActiveFilter(hash(AddRoute)) & filters.Text(AddRoute.ADD_NFT_TEXT)
        return [ConversationHandler(
            entry_points = [MessageHandler(filter_, self.enter)],
            states = {
                self.ON_INPUT_COIN: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.input_coin)
                ],
                self.ON_CONFIRM_COIN: [
                    CallbackQueryHandler(self.cancel_add, '^no$'),
                    CallbackQueryHandler(self.confirm_add, '^yes$'),
                ]
            },
            fallbacks = [MessageHandler(filters.Text(self.CANCEL_TEXT), self.back)],
            per_user = True
        )]
