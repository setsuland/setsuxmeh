from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters
from ..base import CanBackRoute, BaseRoute
from ..start import StartRoute

class AddRoute(CanBackRoute):
    ADD_WALLET_TEXT = "+ Add Wallet"
    ADD_COIN_TEXT = "+ Add Coin"
    ADD_NFT_TEXT = "+ Add NFTs"
    ADD_POOL_TEXT = "+ Add Pools"

    BACK_TEXT = "🔙 Back"

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.enter(update, context)

    def text(self):
        return "Select"
    
    def keyboard(self):
        return ReplyKeyboardMarkup([
            [KeyboardButton(self.ADD_WALLET_TEXT), KeyboardButton(self.ADD_COIN_TEXT)],
            [KeyboardButton(self.ADD_NFT_TEXT), KeyboardButton(self.ADD_POOL_TEXT)],
            [KeyboardButton(self.BACK_TEXT)]
        ], resize_keyboard = True)

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text(self.text(), reply_markup = self.keyboard())

    def route(self):
        return [
            MessageHandler(filters.Text(StartRoute.ADD_TEXT), self.enter),
            MessageHandler(self.IsActiveFilter(hash(self)) & filters.Text(self.BACK_TEXT), self.back)
        ]
    
    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().back(update, context)
        await StartRoute().rebuild(update, context)

