from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler
from ..base import CanBackRoute, BaseRoute
from . import AddRoute
from core.models import Wallet
from ....helpers.decorators import safe_end
import re

class AddWalletRoute(CanBackRoute):
    CANCEL_TEXT = "❌ Cancel"
    WRONG_ADDRESS_TEXT = "Wrong address"
    NAME_TOO_LONG_TEXT = "too long"
    SUCCESS_SAVE_WALLET_TEXT = "Wallet successfully saved."
    ADDRESS_HAS_BEEN_REGISTERED_TEXT = "address has been registered"
    NAME_HAS_BEEN_REGISTERED_TEXT = "name has been registered"

    ON_INPUT_WALLET_ADDRESS, ON_INPUT_WALLET_NAME = range(2)

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await super().rebuild(update, context)

    def send_radix_address_text(self):
        return "Enter Radix Wallet Addresses (Start With account_rdx) : "
    
    def send_radix_wallet_name_text(self):
        return "Enter wallet name : "

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.CANCEL_TEXT)]
            ],
            resize_keyboard = True
        )

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.message.reply_text(self.send_radix_address_text(), reply_markup = self.keyboard())
        return self.ON_INPUT_WALLET_ADDRESS
    
    @safe_end
    async def input_wallet_adress_proccess(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        address = re.sub(r"\W", "", update.message.text)
        if not re.match(r"^account_rdx[a-z0-9]{55}$", address):
            await update.message.reply_text(self.WRONG_ADDRESS_TEXT)
            return

        if await Wallet.objects.filter(address_lower = address.lower()).filter(telegram_id = update.message.from_user.id).aexists():
            await update.message.reply_text(self.ADDRESS_HAS_BEEN_REGISTERED_TEXT)
            return

        await update.message.reply_text(self.send_radix_wallet_name_text())
        context.user_data['address'] = address
        return self.ON_INPUT_WALLET_NAME

    @safe_end
    async def input_wallet_name_proccess(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        name = re.sub(r"\W", "", update.message.text).strip()
        if len(name) > 20:
            await update.message.reply_text(self.NAME_TOO_LONG_TEXT)
            return
        
        if len(name) < 3:
            await update.message.reply_text("Name too short")
            return
        
        if await Wallet.objects.filter(name_lower = name.lower()).filter(telegram_id = update.message.from_user.id).aexists():
            await update.message.reply_text(self.NAME_HAS_BEEN_REGISTERED_TEXT)
            return
        
        address = context.user_data['address']
        context.user_data['address'] = None

        await Wallet.objects.acreate(
            name = name,
            address = address,
            telegram_id = update.message.from_user.id
        )

        await update.message.reply_text(self.SUCCESS_SAVE_WALLET_TEXT)

        await AddRoute().rebuild(update, context)
        return ConversationHandler.END


    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await AddRoute().rebuild(update, context)
        return ConversationHandler.END

    def route(self):
        filter_ = self.IsActiveFilter(hash(AddRoute)) & filters.Text(AddRoute.ADD_WALLET_TEXT)
        return [ConversationHandler(
            entry_points = [MessageHandler(filter_, self.enter)],
            states = {
                self.ON_INPUT_WALLET_ADDRESS: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.input_wallet_adress_proccess)
                ],
                self.ON_INPUT_WALLET_NAME: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.input_wallet_name_proccess)
                ]
            },
            fallbacks = [MessageHandler(filters.Text(self.CANCEL_TEXT), self.back)]
        )]