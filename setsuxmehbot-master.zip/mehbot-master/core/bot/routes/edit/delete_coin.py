from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, \
    InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, \
    ConversationHandler, CallbackQueryHandler
from ..base import CanBackRoute
from ....models import Coin
from asgiref.sync import sync_to_async
from . import EditRoute
import re

class DeleteCoinRoute(CanBackRoute):
    BACK_TEXT = "🔙 Back"
    TEXT = "Select coin to delete"

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.BACK_TEXT)]
            ],
            resize_keyboard = True
        )
    

    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    async def coin_keyboard(self, update: Update):
        coins = Coin.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(coins)
        coin_buttons = []
        for coin in coins:
            coin_buttons.append(InlineKeyboardButton('❌ ' + coin.name, callback_data = f'{hash(self)}_delete_coin_{coin.pk}'))

        return InlineKeyboardMarkup(self.split_list(coin_buttons, 2))
    
    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text("Waiting...", reply_markup = self.keyboard())
        await update.effective_message.reply_text(self.TEXT, reply_markup = await self.coin_keyboard(update))


    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await self.enter(update, context)

    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await EditRoute().rebuild(update, context)
        return ConversationHandler.END
    
    async def delete_and_refresh(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pk = update.callback_query.data.removeprefix(f'{hash(self)}_delete_coin_')
        await Coin.objects.filter(telegram_id = update.effective_user.id).filter(pk = pk).adelete()
        await update.effective_message.edit_reply_markup(reply_markup = await self.coin_keyboard(update))


    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(EditRoute)) & filters.Text(EditRoute.DELETE_COIN_TEXT), self.enter),
            MessageHandler(self.IsActiveFilter(hash(self)) & filters.Text(self.BACK_TEXT), self.back),
            CallbackQueryHandler(self.delete_and_refresh, re.compile(f'{hash(self)}_delete_coin_')),
        ]

