from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters
from ..base import CanBackRoute
from ..start import StartRoute

class EditRoute(CanBackRoute):
    BACK_TEXT = "🔙 Back"
    EDIT_NAME_WALLET_TEXT = "✏️ Edit Wallet Name"
    EDIT_NAME_POOL_TEXT = "✏️ Edit Pool Name"
    DELETE_WALLET_TEXT = "❌ Delete Wallet"
    DELETE_POOL_TEXT = "❌ Delete Pool"
    DELETE_COIN_TEXT = "❌ Delete Coin"
    DELETE_NFT_TEXT = "❌ Delete NFT"

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.enter(update, context)

    def text(self):
        return "Select"
    
    def keyboard(self):
        return ReplyKeyboardMarkup([
            [KeyboardButton(self.EDIT_NAME_WALLET_TEXT)],
            [KeyboardButton(self.DELETE_WALLET_TEXT), KeyboardButton(self.DELETE_POOL_TEXT)],
            [KeyboardButton(self.DELETE_COIN_TEXT), KeyboardButton(self.DELETE_NFT_TEXT)],
            [KeyboardButton(self.BACK_TEXT)]
        ], resize_keyboard = True)

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text(self.text(), reply_markup = self.keyboard())

    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(self)) & filters.Text(self.BACK_TEXT), self.back)
        ]
    
    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        print("KEREN")
        await super().back(update, context)
        await StartRoute().rebuild(update, context)

