from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, \
    InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, \
    ConversationHandler, CallbackQueryHandler
from ..base import CanBackRoute
from ....models import Pool
from asgiref.sync import sync_to_async
from . import EditRoute
from ..add.wallet import AddWalletRoute
import re

class EditPoolRoute(CanBackRoute):
    CANCEL_TEXT = "❌ Cancel"
    TEXT = "Select pool to edit"

    ON_SELECT_pool, ON_INPUT_NEW_NAME = range(2)

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.CANCEL_TEXT)]
            ],
            resize_keyboard = True
        )
    

    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    async def pool_keyboard(self, update: Update):
        pools = Pool.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(pools)
        pool_buttons = []
        for pool in pools:
            pool_buttons.append(InlineKeyboardButton('✏️ ' + pool.name, callback_data = f'{hash(self)}_edit_pool_{pool.pk}'))

        return InlineKeyboardMarkup(self.split_list(pool_buttons, 2))
    
    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text("Waiting...", reply_markup = self.keyboard())
        await update.effective_message.reply_text(self.TEXT, reply_markup = await self.pool_keyboard(update))
        return self.ON_SELECT_pool


    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await self.enter(update, context)

    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await EditRoute().rebuild(update, context)
        return ConversationHandler.END
    
    async def select_pool(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pk = update.callback_query.data.removeprefix(f'{hash(self)}_edit_pool_')
        pool = await Pool.objects.filter(telegram_id = update.effective_user.id).aget(pk = pk)
        context.user_data['coin_id'] = pool.coin_id

        text = f'Current name is {pool.name}, change to?'
        await update.effective_message.edit_text(text)
        return self.ON_INPUT_NEW_NAME

    async def new_name(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        name = re.sub(r"\W", "", update.message.text).strip()   
        if len(name) > 20:
            await update.message.reply_text(AddWalletRoute.NAME_TOO_LONG_TEXT)
            return
            
        if len(name) < 3:
            await update.message.reply_text("Name too short")
            return
            
        if await Pool.objects.filter(name_lower = name.lower()).filter(telegram_id = update.message.from_user.id).aexists():
            await update.message.reply_text(AddWalletRoute.NAME_HAS_BEEN_REGISTERED_TEXT)
            return
            
        coin_id = context.user_data['coin_id']
        context.user_data['coin_id'] = None
        
        await Pool.objects.filter(telegram_id = update.effective_user.id).filter(coin_id = coin_id).aupdate(name = name)

        await update.message.reply_text(AddWalletRoute.SUCCESS_SAVE_pool_TEXT)

        await EditRoute().rebuild(update, context)
        return ConversationHandler.END

    def route(self):
        filter_ = self.IsActiveFilter(hash(EditRoute)) & filters.Text(EditRoute.EDIT_NAME_POOL_TEXT)
        return [ConversationHandler(
            entry_points = [MessageHandler(filter_, self.enter)],
            states = {
                self.ON_SELECT_pool: [
                    CallbackQueryHandler(self.select_pool, re.compile(f'{hash(self)}_edit_pool_'))
                ],
                self.ON_INPUT_NEW_NAME: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.new_name)
                ]
            },
            fallbacks = [MessageHandler(filters.Text(self.CANCEL_TEXT), self.back)]
        )]

