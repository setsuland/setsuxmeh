from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, \
    InputFile, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, \
    ConversationHandler, CallbackQueryHandler
from ..base import CanBackRoute
from ....models import Wallet
from asgiref.sync import sync_to_async
from . import EditRoute
from ..add.wallet import AddWalletRoute
import re

class EditWalletRoute(CanBackRoute):
    CANCEL_TEXT = "❌ Cancel"
    TEXT = "Select wallet to edit"

    ON_SELECT_WALLET, ON_INPUT_NEW_NAME = range(2)

    def keyboard(self):
        return ReplyKeyboardMarkup(
            [
                [KeyboardButton(self.CANCEL_TEXT)]
            ],
            resize_keyboard = True
        )
    

    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    async def wallet_keyboard(self, update: Update):
        wallets = Wallet.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(wallets)
        wallet_buttons = []
        for wallet in wallets:
            wallet_buttons.append(InlineKeyboardButton('✏️ ' + wallet.name, callback_data = f'{hash(self)}_edit_wallet_{wallet.pk}'))

        return InlineKeyboardMarkup(self.split_list(wallet_buttons, 2))
    
    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.effective_message.reply_text("Waiting...", reply_markup = self.keyboard())
        await update.effective_message.reply_text(self.TEXT, reply_markup = await self.wallet_keyboard(update))
        return self.ON_SELECT_WALLET


    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await self.enter(update, context)

    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await EditRoute().rebuild(update, context)
        return ConversationHandler.END
    
    async def select_wallet(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pk = update.callback_query.data.removeprefix(f'{hash(self)}_edit_wallet_')
        wallet = await Wallet.objects.filter(telegram_id = update.effective_user.id).aget(pk = pk)
        context.user_data['address'] = wallet.address

        text = f'Current name is {wallet.name}, change to?'
        await update.effective_message.edit_text(text)
        return self.ON_INPUT_NEW_NAME

    async def new_name(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        name = re.sub(r"\W", "", update.message.text).strip()   
        if len(name) > 20:
            await update.message.reply_text(AddWalletRoute.NAME_TOO_LONG_TEXT)
            return
            
        if len(name) < 3:
            await update.message.reply_text("Name too short")
            return
            
        if await Wallet.objects.filter(name_lower = name.lower()).filter(telegram_id = update.message.from_user.id).aexists():
            await update.message.reply_text(AddWalletRoute.NAME_HAS_BEEN_REGISTERED_TEXT)
            return
            
        address = context.user_data['address']
        context.user_data['address'] = None
        
        await Wallet.objects.filter(telegram_id = update.effective_user.id).filter(address = address).aupdate(name = name)

        await update.message.reply_text(AddWalletRoute.SUCCESS_SAVE_WALLET_TEXT)

        await EditRoute().rebuild(update, context)
        return ConversationHandler.END

    def route(self):
        filter_ = self.IsActiveFilter(hash(EditRoute)) & filters.Text(EditRoute.EDIT_NAME_WALLET_TEXT)
        return [ConversationHandler(
            entry_points = [MessageHandler(filter_, self.enter)],
            states = {
                self.ON_SELECT_WALLET: [
                    CallbackQueryHandler(self.select_wallet, re.compile(f'{hash(self)}_edit_wallet_'))
                ],
                self.ON_INPUT_NEW_NAME: [
                    MessageHandler(filters.TEXT & ~filters.Text(self.CANCEL_TEXT), self.new_name)
                ]
            },
            fallbacks = [MessageHandler(filters.Text(self.CANCEL_TEXT), self.back)]
        )]

