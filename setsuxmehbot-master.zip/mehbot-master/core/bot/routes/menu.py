from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CallbackQueryHandler
from .base import InlineRoute
from .start import StartRoute
from .add import AddRoute
from .edit import EditRoute
from ...models import User, Wallet, Coin, Pool, NFT
import re

class MenuRoute(InlineRoute):
    BACK_TEXT = "🔙 Back"

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.edit_text(self.text(), reply_markup = self.keyboard())

    def text(self):
        return """
Welcome to MEH Bot Tracker!

We're thrilled to have you here to explore the latest updates and features of MEH Bot Tracker. Stay connected and never miss a beat by following us on our social media channels:

Website: https://mehguy.click
X (formerly Twitter): https://x.com/mehguyxrd
Telegram: https://t.me/mehguyxrd

Stay tuned for more exciting news and updates from the MEH Guy project!
"""

    def keyboard(self):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton('+ Add', callback_data  = f'{hash(self)}_add'), InlineKeyboardButton('✏️ Edit', callback_data  = f'{hash(self)}_edit')],
            [InlineKeyboardButton('🙎‍♂️ Profile', callback_data  = f'{hash(self)}_profile'), InlineKeyboardButton('⚙️ Settings', callback_data  = f'{hash(self)}_settings')]
        ])
    
    async def profile(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton(self.BACK_TEXT, callback_data = f'{hash(self)}_back')]
        ])
        text = f'''
Total Wallets: {await Wallet.objects.filter(telegram_id = update.effective_user.id).acount()}
Total Coins: {await Coin.objects.filter(telegram_id = update.effective_user.id).acount()}
Total Pools: {await Pool.objects.filter(telegram_id = update.effective_user.id).acount()}
Total NFTs: {await NFT.objects.filter(telegram_id = update.effective_user.id).acount()}
'''.strip()
        await update.effective_message.edit_text(text, reply_markup = markup)

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        await update.message.reply_text(self.text(), reply_markup = self.keyboard())

    async def add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await AddRoute().enter(update, context)
        await update.callback_query.answer()

    async def edit(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await EditRoute().enter(update, context)
        await update.callback_query.answer()


    async def settings_keyboard(self, update: Update):
        user = await User.objects.aget(telegram_id = update.effective_user.id)
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f'⏰ Min Price Alert ({user.min_price_alert}%)', callback_data = f'{hash(self)}_min_price_alert')],
            [InlineKeyboardButton('❌ Delete Account', callback_data = f'{hash(self)}_delete_account')],
            [InlineKeyboardButton(self.BACK_TEXT, callback_data = f'{hash(self)}_back')]
        ])
    
    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    def percentage_keyboard(self):
        percentages = [1, 5, 10, 15, 20, 30, 50, 60, 70, 80, 90, 100]
        markup = []
        for x in percentages:
            markup.append(
                InlineKeyboardButton(str(x) + '%', callback_data = f'{hash(MenuRoute)}_min_price_alert_{x}')
            )
        
        rv = MenuRoute.split_list(markup, 4)
        rv.append(
            [InlineKeyboardButton(MenuRoute.BACK_TEXT, callback_data = f'{hash(MenuRoute)}_back')]
        )
        return InlineKeyboardMarkup(rv)

    async def settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.edit_reply_markup(await self.settings_keyboard(update))

    async def min_price_alert(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.edit_text("Select", reply_markup = self.percentage_keyboard())

    async def min_price_alert_set(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = await User.objects.aget(pk = update.effective_user.id)
        user.min_price_alert = update.callback_query.data.removeprefix(f"{hash(self)}_min_price_alert_")
        await user.asave()
        await self.settings(update, context)

    async def delete_account(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = await User.objects.aget(pk = update.effective_user.id)
        user.disable = True
        await user.asave()
        await update.effective_message.edit_text('✔️ Successfully')

    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(StartRoute)) & filters.Text(StartRoute.MENU_TEXT), self.enter),
            CallbackQueryHandler(self.add, re.compile(f'^{hash(self)}_add')),
            CallbackQueryHandler(self.edit, re.compile(f'^{hash(self)}_edit')),
            CallbackQueryHandler(self.settings, re.compile(f'^{hash(self)}_settings$')),
            CallbackQueryHandler(self.profile, re.compile(f'^{hash(self)}_profile$')),
            CallbackQueryHandler(self.rebuild, re.compile(f'^{hash(self)}_back$')),
            CallbackQueryHandler(self.min_price_alert, re.compile(f'^{hash(self)}_min_price_alert$')),
            CallbackQueryHandler(self.min_price_alert_set, re.compile(f'^{hash(self)}_min_price_alert_\d+$')),
            CallbackQueryHandler(self.delete_account, re.compile(f'^{hash(self)}_delete_account$')),
        ]
