from django.conf import settings
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import MessageHandler, ContextTypes, filters, CommandHandler
from .base import BaseRoute
from ...models import User
from redis_dict import RedisDict
from ...helpers.redis import parse_redis_url

class StartRoute(BaseRoute):
    ADD_TEXT = "➕ Add"
    BALANCE_TEXT = "💰 Balance"
    MENU_TEXT = "🗂️ Menu"
    COIN_TEXT = "🟡 Coins"
    NFT_TEXT = "🖼️ NFTs"
    POOL_TEXT = "🏊🏻‍♂️ Pools"
    
    _HAS_ROUTE = {}

    # if settings.DEBUG:
    #     _HAS_ROUTE = {}
    # else:
    #     _HAS_ROUTE = RedisDict(namespace = 'has_route', **parse_redis_url(settings.REDIS_URL))

    class NoActiveFilter(filters.BaseFilter):
        def __init__(self):
            super().__init__("no_active_filter")

        def check_update(self, update: Update):
            rv = StartRoute._HAS_ROUTE.get(update.effective_user.id) == None
            StartRoute._HAS_ROUTE[update.effective_user.id] = True
            return rv

    def keyboard(self):
        return ReplyKeyboardMarkup(keyboard = [
            [KeyboardButton(self.ADD_TEXT), KeyboardButton(self.BALANCE_TEXT)],
            [KeyboardButton(self.COIN_TEXT), KeyboardButton(self.NFT_TEXT)],
            [KeyboardButton(self.POOL_TEXT), KeyboardButton(self.MENU_TEXT)]
        ], resize_keyboard = True)
    
    def text(self, name: str):
        return f"""
Welcome {name} to MEH Bot Tracker!

We're thrilled to have you here to explore the latest updates and features of MEH Bot Tracker. Stay connected and never miss a beat by following us on our social media channels:

Website: https://mehguy.click
X (formerly Twitter): https://x.com/mehguyxrd
Telegram: https://t.me/mehguyxrd

Stay tuned for more exciting news and updates from the MEH Guy project!
""".strip()

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        user,  _ = await User.objects.aget_or_create(telegram_id = update.effective_user.id)
        user.disable = False
        await user.asave()
        await update.effective_message.reply_text(self.text(update.effective_user.first_name), reply_markup = self.keyboard())
        self._HAS_ROUTE[update.effective_user.id] = True

    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.enter(update, context)

    def route(self):
        return [
            CommandHandler("start", self.enter),
            MessageHandler(self.NoActiveFilter(), self.enter)
        ]
        