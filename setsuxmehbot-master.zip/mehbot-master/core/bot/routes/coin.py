from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CallbackQueryHandler
from .base import BaseRoute
from .start import StartRoute
from asgiref.sync import sync_to_async
from ...helpers.ociswap import find_ociswap_token
from ...models import Coin
import re, asyncio

class CoinRoute(BaseRoute):
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await self.enter(update, context)

    async def text(self, update: Update, curency = 'xrd'):
        text = ['Your coin:\n']
        coins = Coin.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(coins)
        
        # for coin in coins: 
        async def execute(coin, text):
            token = (await find_ociswap_token(coin.coin_id))[0]
            price_now = round(float(token['price'][curency]['now']), 4)
            text[0] += f"\n<a href='https://www.radixscan.io/entity/{coin.coin_id}'>{coin.name}</a> : {price_now} {curency.upper()} : "
            price_change = round(float(token['price'][curency]['percent_change']['24h']) * 100, 4)
            if price_change > 0:
                text[0] += '⏫ '
            elif price_change < 0:
                text[0] += '🔻 '
            
            text[0] += f'{price_change}%'

        await asyncio.gather(*[execute(coin, text) for coin in coins])

        return text[0]

    def keyboard(self):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton('XRD', callback_data = f'{hash(self)}_change_xrd'), InlineKeyboardButton('USD', callback_data = f'{hash(self)}_change_usd')],
        ])

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        message = await update.message.reply_text('Wait...')
        text = await self.text(update)
        await message.edit_text(text, reply_markup = self.keyboard(), parse_mode = 'HTML')

    async def change_currency(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        currency = update.callback_query.data.removeprefix(f'{hash(self)}_change_')
        text = await self.text(update, curency = currency)
        try:
            await update.effective_message.edit_text(text, reply_markup = self.keyboard(), parse_mode = 'HTML')
        except:
            pass

        await update.callback_query.answer()

    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(StartRoute)) & filters.Text(StartRoute.COIN_TEXT), self.enter),
            CallbackQueryHandler(self.change_currency, re.compile(f'^{hash(self)}_change_'))
        ]

