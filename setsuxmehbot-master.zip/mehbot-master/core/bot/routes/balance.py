from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CallbackQueryHandler
from ...models import Wallet, Coin
from ...helpers import radixapi
from ...helpers import ociswap
from asgiref.sync import sync_to_async
from .base import InlineRoute
from .start import StartRoute
import re, asyncio

class BalanceRoute(InlineRoute):
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.edit_text(self.text(), reply_markup = await self.keyboard(update.effective_user.id))

    def text(self):
        return "Select wallet"
    
    def notfound_text(self):
        return "No wallet found"

    @staticmethod
    def split_list(input_list, chunk_size):
        return [input_list[i:i+chunk_size] for i in range(0, len(input_list), chunk_size)]

    async def keyboard(self, user_id: int):
        wallets = Wallet.objects.filter(telegram_id = user_id)
        await sync_to_async(len)(wallets) # execute
        list_keyboard = []
        for wallet in wallets:
            list_keyboard.append(
                InlineKeyboardButton('💰 ' + wallet.name, callback_data = f'{hash(self)}_wallet_{wallet.pk}')
            )
        
        return InlineKeyboardMarkup(self.split_list(list_keyboard, 2))
    
    def wallet_keyboard(self, user_id):
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton('XRD', callback_data = f'{hash(self)}_wallet_xrd_{user_id}'), InlineKeyboardButton('USD', callback_data = f'{hash(self)}_wallet_usd_{user_id}')],
                [InlineKeyboardButton('🔙 Back', callback_data = f'{hash(self)}_back')]
            ]
        )

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)

        text = self.text()
        if not await Wallet.objects.filter(telegram_id = update.effective_user.id).aexists():
            text = self.notfound_text()

        await update.message.reply_text(text, reply_markup = await self.keyboard(update.effective_message.from_user.id))

    async def get_wallet(self, update: Update, context: ContextTypes.DEFAULT_TYPE, wallet_id = None, convert_to_price = 'XRD'):
        message_sent = await update.effective_message.edit_text('Wait...')
        if wallet_id is None:
            wallet_id = update.callback_query.data.removeprefix(f'{hash(self)}_wallet_')

        wallet = await Wallet.objects.filter(telegram_id = update.effective_user.id).aget(pk = wallet_id)
        tokens = await radixapi.get_balance(wallet.address)
        xrd_token = (await ociswap.get_ociswap_token('resource_rdx1tknxxxxxxxxxradxrdxxxxxxxxx009923554798xxxxxxxxxradxrd'))[0]

        if not tokens:
            await update.effective_message.edit_text(f'No coin found in wallet {wallet.name}', reply_markup = self.wallet_keyboard(wallet_id))
            return

        text = ['Token:']

        async def execute(token, text):
            # coin = await Coin.objects.filter(telegram_id = update.effective_user.id).aget(coin_id = token['fungible_resource_address'])
            resource_address = token['fungible_resource_address']
            # coin = await ociswap.get_ociswap_token(resource_address)
            # print(coin)
            amount = round(float(token['amount']), 4)

            ociswap_token = (await ociswap.get_ociswap_token(resource_address))[0]

            if not ociswap_token.get('symbol'):
                return

            if not ociswap_token.get('price'):
                price = "-"
            else:
                if convert_to_price == 'XRD':
                    price = str(
                        round(
                            float(ociswap_token['price']['xrd']['now']) * amount, 2
                        )
                    ) + ' XRD'
                elif convert_to_price == 'USD':
                    price = str(
                        round(
                            float(ociswap_token['price']['usd']['now']) * amount, 2
                        )
                    ) + ' USD'

            text[0] += f'\n<b><a href="https://www.radixscan.io/entity/{resource_address}">${ociswap_token["symbol"].upper()}</a></b> <code>{amount}</code> = {price}'
        
        await asyncio.gather(*[execute(token, text) for token in tokens[:15]])

        if len(tokens) > 15:
            text[0] += f'\n...\n/detail_wallet_{wallet.pk}'
        
        staking_balance = round(await radixapi.get_staking_balance(wallet.address), 2)
        staking_balance_usd = round(
            staking_balance * float(xrd_token['price']['usd']['now'])
        )
        text[0] += f'\n\nStaking:\n<b><a href="https://www.radixscan.io/entity/resource_rdx1tknxxxxxxxxxradxrdxxxxxxxxx009923554798xxxxxxxxxradxrd">$XRD</a></b> {staking_balance} = {staking_balance_usd} USD'
        await message_sent.edit_text(text[0], reply_markup = self.wallet_keyboard(wallet_id), parse_mode = 'HTML')

    async def change_to_xrd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        wallet_id = update.callback_query.data.removeprefix(f'{hash(self)}_wallet_xrd_')
        try:
            await self.get_wallet(update, context, wallet_id, "XRD")
        except:
            pass

        await update.callback_query.answer('Changed to XRD')

    async def change_to_usd(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        wallet_id = update.callback_query.data.removeprefix(f'{hash(self)}_wallet_usd_')

        try:
            await self.get_wallet(update, context, wallet_id, "USD")
        except:
            pass

        await update.callback_query.answer('Changed to USD')


    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(StartRoute)) & filters.Text(StartRoute.BALANCE_TEXT), self.enter),
            CallbackQueryHandler(self.get_wallet, re.compile(f'^{hash(self)}_wallet_\d+$')),
            CallbackQueryHandler(self.change_to_xrd, re.compile(f'^{hash(self)}_wallet_xrd_\d+$')),
            CallbackQueryHandler(self.change_to_usd, re.compile(f'^{hash(self)}_wallet_usd_\d+$')),
            CallbackQueryHandler(self.rebuild, re.compile(f'^{hash(self)}_back$'))
        ]