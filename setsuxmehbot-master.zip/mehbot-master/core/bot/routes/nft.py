from .start import StartRoute
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters
from .base import InlineRoute
from ...models import NFT
from ...helpers.radishsquare import get_nft_detail
from asgiref.sync import sync_to_async

class NFTRoute(InlineRoute):
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pass

    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await super().enter(update, context)
        nfts = NFT.objects.filter(telegram_id = update.effective_user.id)
        await sync_to_async(len)(nfts)
        text = 'Your NFTs list:\n'
        for nft in nfts:
            nft_detail = await get_nft_detail(nft.radishsquare_id)
            floor_price = int(nft_detail['stats']['floor_price'])
            text += f'\n<a href="https://radishsquare.com/collections/{nft.radishsquare_id}">{nft.name}</a> : {floor_price} XRD'       

        await update.effective_message.reply_text(text, parse_mode = 'HTML')
    
    def route(self):
        return [
            MessageHandler(self.IsActiveFilter(hash(StartRoute)) & filters.Text(StartRoute.NFT_TEXT), self.enter)
        ]