from abc import ABC, abstractmethod
from telegram import Update
from telegram.ext import ContextTypes, filters
from redis_dict import RedisDict
from django.conf import settings
from ...helpers.redis import parse_redis_url
from abc import ABCMeta

class ABCMeta(ABCMeta):
    def __hash__(self) -> int:
        return hash(str(self.__mro__))

class BaseRoute(ABC, metaclass = ABCMeta):
    _USER_ROUTES = {}
    # if settings.DEBUG:
    #     _USER_ROUTES = {}
    # else:
    #     _USER_ROUTES = RedisDict(namespace = 'user_routes', **parse_redis_url(settings.REDIS_URL))

    class IsActiveFilter(filters.BaseFilter):
        def __init__(self, unique):
            self.unique = unique
            super().__init__("active_filter")

        def check_update(self, update: Update):
            return BaseRoute._USER_ROUTES.get(update.message.from_user.id) == self.unique

    def addToRoute(self, user_id: int):
        BaseRoute._USER_ROUTES[user_id] = hash(self)

    @abstractmethod
    async def rebuild(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pass
    
    @abstractmethod
    async def enter(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.message:
            user_id = update.message.from_user.id
        else:
            user_id = update.callback_query.from_user.id
        
        self.addToRoute(user_id)        

    @abstractmethod
    def route(self):
        pass

    def __hash__(self) -> int:
        return hash(str(self.__class__.__mro__))


class InlineRoute(BaseRoute):
    def addToRoute(self, user_id: int):
        pass


class CanBackRoute(BaseRoute):
    @abstractmethod
    async def back(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        pass