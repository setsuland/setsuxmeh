from telegram.ext import ApplicationBuilder, Defaults
from django.conf import settings

df = Defaults(block = False)

app = ApplicationBuilder().token(settings.TELEGRAM_API_TOKEN).defaults(df).build()
