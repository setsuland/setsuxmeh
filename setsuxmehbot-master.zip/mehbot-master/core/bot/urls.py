from .app import app
from .routes.start import StartRoute
from .routes.add import AddRoute
from .routes.add.wallet import AddWalletRoute
from .routes.add.coin import AddCoinRoute
from .routes.add.pool import AddPoolRoute
from .routes.balance import BalanceRoute
from .routes.menu import MenuRoute
from .routes.coin import CoinRoute
from .routes.edit import EditRoute
from .routes.edit.delete_wallet import DeleteWalletRoute
from .routes.edit.delete_coin import DeleteCoinRoute
from .routes.edit.edit_wallet import EditWalletRoute
# from .routes.edit.edit_pool import EditPoolRoute
from .routes.edit.delete_nft import DeleteNFTRoute
from .routes.edit.delete_pool import DeletepoolRoute
from .routes.add.nft import AddNFTRoute
from .routes.pool import PoolRoute
from .routes.nft import NFTRoute
from .routes.detail_wallet import DetailWalletRoute

# import traceback

# async def error_handler(*args):
#     print(args)
#     traceback.print_exc()

# app.add_error_handler(error_handler)

app.add_handlers(StartRoute().route(), -1)
app.add_handlers(AddRoute().route())
app.add_handlers(AddWalletRoute().route())
app.add_handlers(AddCoinRoute().route())
app.add_handlers(BalanceRoute().route())
app.add_handlers(MenuRoute().route())
app.add_handlers(CoinRoute().route())
app.add_handlers(EditRoute().route())
app.add_handlers(DeleteWalletRoute().route())
app.add_handlers(DeleteCoinRoute().route())
app.add_handlers(EditWalletRoute().route())
app.add_handlers(AddNFTRoute().route())
app.add_handlers(NFTRoute().route())
app.add_handlers(DeleteNFTRoute().route())
app.add_handlers(AddPoolRoute().route())
app.add_handlers(DeletepoolRoute().route())
app.add_handlers(PoolRoute().route())
app.add_handlers(DetailWalletRoute().route())
# app.add_handlers(EditPoolRoute().route())