from django.db import models
from django.db.models.functions import Lower
from django.core.validators import MinValueValidator, MaxValueValidator

class User(models.Model):
    telegram_id = models.CharField(max_length = 20, primary_key = True)
    disable = models.BooleanField(default = False)
    min_price_alert = models.PositiveSmallIntegerField(default = 1, validators = [
        MinValueValidator(1),
        MaxValueValidator(100)
    ])


class Wallet(models.Model):
    class Meta:
        unique_together = ('telegram_id', 'address')

    class WalletManager(models.Manager):
        def get_queryset(self) -> models.QuerySet:
            return super().get_queryset().annotate(address_lower = Lower('address')).annotate(name_lower = Lower('name'))

    objects = WalletManager()

    telegram_id = models.CharField(max_length = 20)
    name = models.CharField(max_length = 20)
    address = models.CharField(max_length = 100)


class Coin(models.Model):
    class Meta:
        unique_together = ('telegram_id', 'coin_id')

    coin_id = models.CharField(max_length = 255)
    name = models.CharField(max_length = 100)
    telegram_id = models.CharField(max_length = 20)


class Pool(models.Model):
    class Meta:
        unique_together = ('telegram_id', 'coin_id')

    coin_id = models.CharField(max_length = 255)
    name = models.CharField(max_length = 100)
    telegram_id = models.CharField(max_length = 20)



class NFT(models.Model):
    nft_id = models.CharField(max_length = 255)
    radishsquare_id = models.PositiveIntegerField()
    name = models.CharField(max_length = 100)
    telegram_id = models.CharField(max_length = 20)