from django.core.management import BaseCommand
from concurrent.futures import ThreadPoolExecutor
from telebot import TeleBot
from django.conf import settings
from core.helpers.ociswap import get_ociswap_token_sync
from core.models import Wallet, User, Coin, Pool
import time, traceback, redis

bot = TeleBot(settings.TELEGRAM_API_TOKEN)

pool = ThreadPoolExecutor(max_workers = 10)


class Command(BaseCommand):
#     def listen_liquidity(self):
#         address_used = []
#         coins = Pool.objects.all()
#         for coin in coins:
#             if coin.coin_id in address_used:
#                 continue

#             address_used.append(coin.coin_id)
#             token = get_ociswap_token_sync(coin.coin_id)[0]
                    
#             liquidity_now = float(token['liquidity']['usd']['now'])
#             liquidity_previous = self.r.get(f'liquidity_{coin.coin_id}')
#             if liquidity_previous:
#                 liquidity_previous = float(liquidity_previous)
#                 if liquidity_now != liquidity_previous:
#                     if liquidity_now > liquidity_previous:
#                         boosted_liquidity = abs(round(liquidity_now - liquidity_previous, 4))
#                         text = f'''
# 🚀 <b>${token['symbol'].upper()}</b> Liquidity Boosted! (${boosted_liquidity}) | Current Liquidity: (~${round(liquidity_now, 4)})
# '''.strip()
#                     else:
#                         reduced_liquidity = abs(round(liquidity_previous - liquidity_now, 4))
#                         text = f'''
# 🔻 <b>${token['symbol'].upper()}</b> Liquidity Reduced! (-${reduced_liquidity}) | Current Liquidity: (~${round(liquidity_now, 4)})
# '''.strip()
#                     for x in coins.filter(coin_id = coin.coin_id):
#                         user = User.objects.filter(disable = False).filter(telegram_id = x.telegram_id).first()
#                         if not user:
#                             continue

#                         pool.submit(lambda: bot.send_message(x.telegram_id, text, parse_mode = 'HTML'))


#             self.r.set(f'liquidity_{coin.coin_id}', liquidity_now, ex = 3600)

    @staticmethod
    def calculate_percentage(value1, value2):
        if value1 == 0 or value2 == 0:
            raise ValueError("Cannot calculate percentage if one of the values is zero.")
        else:
            percentage = abs((value1 - value2) / value2) * 100
            return percentage

    def listen_liquidity(self):
        coins = Pool.objects.all()
        for coin in coins:
            user = User.objects.filter(disable = False).filter(telegram_id = coin.telegram_id).first()
            if not user:
                continue

            token = get_ociswap_token_sync(coin.coin_id)[0]
            liquidity_now = float(token['liquidity']['usd']['now'])
            previous_liquidity = self.r.get(f'liquidity_{coin.telegram_id}_{coin.coin_id}')
            if not previous_liquidity:
                previous_liquidity = liquidity_now
            else:
                previous_liquidity = float(previous_liquidity)
            
            if liquidity_now != previous_liquidity:
                if liquidity_now > previous_liquidity:
                    boosted_liquidity = abs(round(liquidity_now - previous_liquidity, 4))
                    text = f'''
🚀 <b>${token['symbol'].upper()}</b> Liquidity Boosted! (${boosted_liquidity}) | Current Liquidity: (~${round(liquidity_now, 4)})
'''.strip()
                else:
                    reduced_liquidity = abs(round(previous_liquidity - liquidity_now, 4))
                    text = f'''
🔻 <b>${token['symbol'].upper()}</b> Liquidity Reduced! (-${reduced_liquidity}) | Current Liquidity: (~${round(liquidity_now, 4)})
'''.strip()
                pool.submit(bot.send_message, coin.telegram_id, text, parse_mode = 'HTML')

            self.r.set(f'liquidity_{coin.telegram_id}_{coin.coin_id}', liquidity_now, ex = 3600)



    def listen_price(self):
        coins = Coin.objects.all()
        for coin in coins:
            user = User.objects.filter(disable = False).filter(telegram_id = coin.telegram_id).first()
            if not user:
                continue

            token = get_ociswap_token_sync(coin.coin_id)[0]
            price_now = float(token['price']['usd']['now'])
            previous_price = self.r.get(f'price_{coin.telegram_id}_{coin.coin_id}')
            if not previous_price:
                self.r.set(f'price_{coin.telegram_id}_{coin.coin_id}', price_now)
                previous_price = price_now
            else:
                previous_price = float(previous_price)
            
            if price_now != previous_price:
                percentage_change = round(self.calculate_percentage(price_now, previous_price), 2)
                if percentage_change < user.min_price_alert:
                    continue

                self.r.set(f'price_{coin.telegram_id}_{coin.coin_id}', price_now)
                if price_now > previous_price:
                    text = f'''
🚀 <b>${token['symbol'].upper()}</b> price changed +%{percentage_change}! Current price ${round(price_now, 4)}
'''.strip()
                else:
                    text = f'''
🔻 <b>${token['symbol'].upper()}</b> price changed -%{percentage_change}! Current price ${round(price_now, 4)}
'''.strip()
                
                pool.submit(bot.send_message, coin.telegram_id, text, parse_mode = 'HTML')
                

    def handle(self, *args, **options):
        print("TOKEN LISTENER STARTED!!")
        self.r = redis.from_url(settings.REDIS_URL)
        
        while True:
            try:
                self.listen_liquidity()
                self.listen_price()
            except KeyboardInterrupt:
                break
            except:
                traceback.print_exc()
            finally:
                time.sleep(300)