from django.core.management import BaseCommand
from concurrent.futures import ThreadPoolExecutor
from telebot import TeleBot
from django.conf import settings
from core.helpers.radixapi import get_lastest_transactions_sync, get_transaction_receipt_sync
from core.helpers.ociswap import get_ociswap_token_sync
from core.models import Wallet, User
import time, traceback, redis

bot = TeleBot(settings.TELEGRAM_API_TOKEN)

pool = ThreadPoolExecutor(max_workers = 10)

class Command(BaseCommand):
    
    def handle(self, *args, **options):
        print("TX LISTENER STARTED!!")
        r = redis.from_url(settings.REDIS_URL)
        
        while True:
            try:
                transactions = get_lastest_transactions_sync(20)
                for transaction in transactions:
                    txhash = transaction['intent_hash']
                    if r.get('txhash_' + txhash) is None:
                        r.set('txhash_' + txhash, 'true', ex = 86400)
                    else:
                        continue

                    tx = get_transaction_receipt_sync(txhash)

                    if tx['transaction'].get('message'):
                        message = tx['transaction']['message']['content']['value']
                    else:
                        message = '-'

                    balance_changes = tx['transaction']['balance_changes']['fungible_balance_changes']
                    for balance_change in balance_changes:
                        balance = (float(balance_change['balance_change']))
                        balance_rounded = round(balance, 4)
                        entity_address = balance_change['entity_address']
                        resource_address = balance_change['resource_address']

                        wallets = Wallet.objects.filter(address = entity_address)
                        if wallets.exists():

                            resource = get_ociswap_token_sync(resource_address)[0]

                            usd_amount = round(
                                float(resource['price']['usd']['now']) * balance_rounded, 4
                            )
                            tx_hash_text = f"<a href='https://www.radixscan.io/transaction/{txhash}'>[View Transaction ↗️]</a>"
                            for wallet in wallets:
                                if not User.objects.filter(disable = False).filter(telegram_id = wallet.telegram_id).exists():
                                    continue
                                
                                if balance > 0:
                                    text = f'''
🚨📢 Wallet Alert! 📢🚨

{wallet.name}
Received: <b>{abs(balance_rounded)} ${resource["symbol"].upper()}</b> (~${usd_amount})

{tx_hash_text}

Message: {message}
🚨🔥🚨
'''.strip()
                                else:
                                      text = f'''
🚨📢 Wallet Alert! 📢🚨

{wallet.name}
Transferred: <b>{abs(balance_rounded)} ${resource["symbol"].upper()}</b> (~${usd_amount})

{tx_hash_text}

Message: {message}
🚨🔥🚨
'''.strip()
                                pool.submit(bot.send_message, wallet.telegram_id, text, parse_mode = 'HTML')


                time.sleep(3)
            except KeyboardInterrupt:
                break
            except:
                traceback.print_exc()