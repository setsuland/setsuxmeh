from django.core.management import BaseCommand
from django.conf import settings
import os

class Command(BaseCommand):
    def handle(self, *args, **options):
        from core.bot.app import app
        print("BOT STARTED!")

        if settings.DEBUG:
            app.run_polling(drop_pending_updates = True)
        else:
            app.run_webhook(listen = "0.0.0.0", port = 8000, webhook_url = "https://meh.salism3.dev/supersecret/saliskerenjasa", url_path = "/supersecret/saliskerenjasa")