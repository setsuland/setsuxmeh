import functools
from redis.asyncio import Redis
from django.conf import settings
from core.bot.routes.base import BaseRoute
import pickle
from telegram.ext import ConversationHandler

r = Redis.from_url(settings.REDIS_URL)

def cache_async(time_seconds):
    def actual_decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            cache_data = await r.get(f'cache_{hash(func)}{args}{kwargs}')
            if cache_data:
                return pickle.loads(cache_data)

            rv = await func(*args, **kwargs)
            cache_data = pickle.dumps(rv)
            await r.set(f'cache_{hash(func)}{args}{kwargs}', cache_data, ex = time_seconds)
            return rv
        return wrapper
    
    return actual_decorator

def safe_end(func):
    async def inner(route: BaseRoute, update, context):
        filter_ = route.IsActiveFilter(hash(route))

        if not filter_.check_update(update):
            return ConversationHandler.END
        
        return await func(route, update, context)

    return inner