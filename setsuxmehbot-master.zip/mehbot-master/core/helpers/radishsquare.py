import requests
from cache_decorator import Cache
from asgiref.sync import sync_to_async

@Cache(validity_duration = '1d')
def get_nfts_sync():
    result = requests.post('https://api.radishsquare.com/getShortCollections')
    return result.json()['collections']

def find_nfts_sync(query: str):
    nfts = get_nfts_sync()
    result = []

    for ntf in nfts:
        if query.lower() in ntf['name'].lower():
            result.append(ntf)
    
    return result

@Cache(validity_duration = '3m')
def get_nft_detail_sync(id_: int):
    return requests.get('https://api.radishsquare.com/getCollectionById?id=' + str(id_)).json()

@Cache(validity_duration = '30d')
def get_nft_detail_long_cache_sync(id_: int):
    return requests.get('https://api.radishsquare.com/getCollectionById?id=' + str(id_)).json()


get_nfts = sync_to_async(get_nfts_sync)
find_nfts = sync_to_async(find_nfts_sync)
get_nft_detail = sync_to_async(get_nft_detail_sync)
get_nft_detail_long_cache = sync_to_async(get_nft_detail_long_cache_sync)