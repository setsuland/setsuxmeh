import urllib.parse

def parse_redis_url(redis_url):
    url_parts = urllib.parse.urlparse(redis_url)
    host = url_parts.hostname
    port = url_parts.port or 6379  # default port 6379 if not specified
    username = url_parts.username
    password = url_parts.password
    db = int(url_parts.path.lstrip('/') or 0)  # default database 0 if not specified
    return {
        "host": host,
        "port": port,
        "username": username,
        "password": password,
        "db": db
    }