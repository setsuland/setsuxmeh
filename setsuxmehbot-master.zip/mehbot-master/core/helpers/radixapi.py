import requests
from asgiref.sync import sync_to_async
from core.helpers.decorators import cache_async
from cache_decorator import Cache
from requests_ratelimiter import LimiterSession
from . import ociswap

RADIX_CORE_API_BASE_URL = 'https://radix-mainnet.rpc.grove.city/v1/e96d68c2/core/'
RADIX_GATEWAY_API_BASE_URL = 'https://mainnet.radixdlt.com/'
RADIX_API_NET_BEARER = "6ea1ZOrXBiWZ6dgSee8JIj1D4UEbDYuxIxq3ab67fJc"
RADIX_API_NET_BASE_URL = "https://api.radixapi.net/"

def get_balance_sync(address: str):
    response = requests.post(RADIX_CORE_API_BASE_URL + 'lts/state/account-all-fungible-resource-balances', json = {
        'network': 'mainnet',
        'account_address': address,
    })
    result = response.json()['fungible_resource_balances']
    return result


get_balance = sync_to_async(get_balance_sync)

def get_lastest_transactions_sync(limit = 10):
    response = requests.post(RADIX_GATEWAY_API_BASE_URL + 'stream/transactions', json = {
        'limit_per_page': limit
    })
    result = response.json()['items']
    return result



get_lastest_transactions = sync_to_async(get_lastest_transactions_sync)

def get_transaction_receipt_sync(intent_hash: str):
    response = requests.post(RADIX_GATEWAY_API_BASE_URL + 'transaction/committed-details', json = {
        "intent_hash": intent_hash,
        "opt_ins": {
            "balance_changes": True
        }
    })
    result = response.json()
    return result


get_transaction_receipt = sync_to_async(get_transaction_receipt_sync)

radix_api_net_session = LimiterSession(per_minute = 60)

@Cache(validity_duration = '3m')
def get_nft_sync(resource_address: str):
    url = RADIX_API_NET_BASE_URL + 'v1/token/details/' + resource_address
    result = radix_api_net_session.get(url, headers = {
        'Authorization': 'Bearer ' + RADIX_API_NET_BEARER
    })
    return result.json()

get_nft = sync_to_async(get_nft_sync)


@Cache(validity_duration = '1d')
def get_token_sync(resource_address: str):
    url = RADIX_API_NET_BASE_URL + 'v1/token/price/current?resource_addresses=' + resource_address
    result = radix_api_net_session.get(url, headers = {
        'Authorization': 'Bearer ' + RADIX_API_NET_BEARER
    })
    return result.json()['data'][resource_address]

@Cache(validity_duration = '3m')
def get_staking_balance_sync(account_address: str):
    validators = get_validator_list_sync()
    validators_parsed = {}
    for validator in validators:
        validators_parsed[validator['stake_unit_resource_address']] = validator['address']

    rv = 0

    url = RADIX_GATEWAY_API_BASE_URL + 'state/entity/details'
    payload = {"opt_ins":{"ancestor_identities":False,"component_royalty_vault_balance":False,"package_royalty_vault_balance":False,"non_fungible_include_nfids":True,"explicit_metadata":[]},"addresses":[account_address],"aggregation_level":"Vault"}
    for item in requests.post(url, json = payload).json()['items'][0]['fungible_resources']['items']:
        if validators_parsed.get(item['resource_address']):
            amount = float(item['vaults']['items'][0]['amount']) * get_lsu_xrd_sync(validators_parsed.get(item['resource_address']))
            rv += amount

    url = RADIX_GATEWAY_API_BASE_URL + 'state/entity/page/fungibles/'
    payload = {"at_ledger_state":{"state_version":72887219},"cursor":"eyJvIjoxMDB9","address":account_address,"aggregation_level":"Vault","opt_ins":{"explicit_metadata":[]}}
    for item in requests.post(url, json = payload).json()['items']:
        if validators_parsed.get(item['resource_address']):
            amount = float(item['vaults']['items'][0]['amount']) * get_lsu_xrd_sync(validators_parsed.get(item['resource_address']))
            rv += amount

    return rv

get_staking_balance = sync_to_async(get_staking_balance_sync)

@Cache(validity_duration = '7d')
def get_lsu_xrd_sync(validator_address: str):
    url = RADIX_API_NET_BASE_URL + 'v1/validator/lsu_xrd_factor/' + validator_address
    result = radix_api_net_session.get(url, headers = {
        'Authorization': 'Bearer ' + RADIX_API_NET_BEARER
    })
    return result.json()['data'][0]['xrd_lsu_factor']

@Cache(validity_duration = '3d')
def get_validator_list_sync():
    url = RADIX_GATEWAY_API_BASE_URL + 'state/validators/list'
    payload = {"cursor":None}

    rv = []
    for item in requests.post(url, json = payload).json()['validators']['items']:
        x = {}
        x['address'] = item['address']
        x['stake_unit_resource_address'] = item['state']['stake_unit_resource_address']
        rv.append(x)

    return rv

get_token = sync_to_async(get_token_sync)

@cache_async(5 * 60)
async def get_safe_token(resource_address: str):
    try:
        token = await get_token(resource_address)
        return {
            'name': token['name'],
            'symbol': token['symbol'].removeprefix('$'),
            'price': token['usd_price']
        }
    except:
        token = await ociswap.get_ociswap_token(resource_address, list_ = False)
        price = 0

        if token.get('price'):
            price = float(token['price']['usd']['now'])
        
        return {
            'name': token['name'],
            'symbol': token['symbol'],
            'price': price
        }