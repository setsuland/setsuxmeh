# from django.conf import settings
# import requests, redis, json
import requests
from asgiref.sync import sync_to_async
from cache_decorator import Cache
from core.helpers.decorators import cache_async
import aiohttp

# @sync_to_async
@Cache(validity_duration = '3m')
def find_ociswap_token_sync(query: str) -> list:    
    respone = requests.get(f"https://api.ociswap.com/tokens?query={query}&order=market_cap_circulating_usd_now&direction=desc")
    result = respone.json()['data']

    return result


@cache_async(3 * 60)
async def find_ociswap_token(query: str) -> list:
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.ociswap.com/tokens?query={query}&order=market_cap_circulating_usd_now&direction=desc") as response:
            result = await response.json()
            return result['data']


@Cache(validity_duration = '4m')
def get_ociswap_token_sync(address: str, list_ = True):    
    respone = requests.get(f"https://api.ociswap.com/tokens/{address}")
    result = respone.json()

    if list_:
        return [result]
    
    return result

# find_ociswap_token = sync_to_async(find_ociswap_token_sync)
# get_ociswap_token = sync_to_async(get_ociswap_token_sync)

# @Cache(validity_duration = '4m')
@cache_async(4 * 60)
async def get_ociswap_token(address: str, list_ = True):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.ociswap.com/tokens/{address}") as response:
            result = await response.json()
            if list_:
                return [result]
            
            return result



