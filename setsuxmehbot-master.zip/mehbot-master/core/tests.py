from django.test import TestCase
from telethon.sync import TelegramClient
from telethon.types import Message
from django.utils.crypto import get_random_string
import time

TG_CLIENT: TelegramClient = None

class BaseTest(TestCase):
    username = '@salisgantengdor_bot'

    def get_latest_message(self, index: int = 0) -> Message:
        return TG_CLIENT.get_messages(self.username, limit = index + 1)[index]
    
    def send_message(self, text: str):
        TG_CLIENT.send_message(self.username, text)

    @classmethod
    def setUpTestData(cls):
        global TG_CLIENT
        client = TelegramClient("test", 611335, "d524b414d21f4d37f08684c1df41ac9c")
        client.start()
        TG_CLIENT = client


class TestWalletAdd(BaseTest):
    def base_add_wallet(self):
        from core.bot.routes.start import StartRoute
        from core.bot.routes.add import AddRoute

        self.send_message('/start')
        time.sleep(3)
        self.send_message(StartRoute.ADD_TEXT)
        time.sleep(2)
        self.send_message(AddRoute.ADD_WALLET_TEXT)
        time.sleep(2)

    def test_1_add_wallet(self):
        from core.bot.routes.add.wallet import AddWalletRoute

        self.base_add_wallet()
        time.sleep(2)

        address = get_random_string(55).lower()
        self.send_message(address)
        time.sleep(2)
        
        self.assertEqual(self.get_latest_message().message, AddWalletRoute.WRONG_ADDRESS_TEXT, "must wrong address")
        self.send_message("account_rdx" + address)

        time.sleep(2)

        self.send_message(get_random_string(21))

        time.sleep(2)

        self.assertEqual(self.get_latest_message().message, AddWalletRoute.NAME_TOO_LONG_TEXT, "must too long")

        name = get_random_string(20)
        self.send_message(name)
        time.sleep(2)

        self.assertEqual(self.get_latest_message(index = 1).message, AddWalletRoute.SUCCESS_SAVE_WALLET_TEXT, "must success save")

        self.base_add_wallet()

        time.sleep(2)

        self.send_message("account_rdx" + address)
        time.sleep(2)

        self.assertEqual(self.get_latest_message().message, AddWalletRoute.ADDRESS_HAS_BEEN_REGISTERED_TEXT, "address dont duplicate")

        self.send_message("account_rdx" + get_random_string(55).lower())
        time.sleep(2)


        self.send_message(name)
        time.sleep(2)

        self.assertEqual(self.get_latest_message().message, AddWalletRoute.NAME_HAS_BEEN_REGISTERED_TEXT, "name dont duplicate")
 

        